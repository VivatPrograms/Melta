import pygame
from Settings import *
class Item(pygame.sprite.Sprite):
    def __init__(self,ID,durability,quantity,pos,groups):
        super().__init__(groups)
        self.ID = ID
        self.dur = durability
        self.quantity = quantity
        self.pos = pos
        self.image = pygame.Surface((tile_size, tile_size))
        self.image.fill('red')
        self.rect = self.image.get_rect(topleft=self.pos)
        self.type = 'item_drop'
    def block(self):
        pass