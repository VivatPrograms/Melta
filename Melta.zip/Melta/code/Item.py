import pygame
from Settings import *
class Item(pygame.sprite.Sprite):
    def __init__(self,ID,durability,quantity,pos,groups,color):
        super().__init__(groups)
        self.ID = ID
        self.dur = durability
        self.quantity = quantity
        self.pos = pos
        self.image = pygame.Surface((tile_size, tile_size))
        self.image.fill(color)
        self.rect = self.image.get_rect(topleft=self.pos)
        if 1<=self.ID<=2:
            self.sprite_type = 'item_drop'
        if self.ID == 3:
            self.sprite_type = 'block'