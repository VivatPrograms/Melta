import pygame
from Settings import *
class Item(pygame.sprite.Sprite):
    def __init__(self,ID,durability,quantity=1,pos=(0,0)):
        super().__init__()
        self.ID = ID
        self.dur = durability
        self.quantity = quantity
        self.pos = pos
        self.image = pygame.Surface((tile_size, tile_size))
        self.image.fill('red')
        self.rect = self.image.get_rect(center=(self.pos))

    def drop(self):
        pass
    def block(self):
        pass
    def misc(self):
        pass