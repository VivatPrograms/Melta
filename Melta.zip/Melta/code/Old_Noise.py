import random
random.seed(1)
class PerlinNoise:
    def random_number(self):
        return random.random()
    def random_int(self):
        return random.randint(0,100)

    def perlin_noise(self,landmass,r,a,n,d,key):
        self.perlin = PerlinNoise()
        if key == 'float':
            r = self.perlin.random_number() + 1 if r == '#' else 0
            a = self.perlin.random_number() + 1 if a == '#' else 0
            n = self.perlin.random_number() + 1 if n == '#' else 0
            d = self.perlin.random_number() + 1 if d == '#' else 0
            noise = (r+a+n+d) / (4 + landmass)
            return noise
        if key == 'int':
            r = self.perlin.random_int() + 1 if r == '#' else 0
            a = self.perlin.random_int() + 1 if a == '#' else 0
            n = self.perlin.random_int() + 1 if n == '#' else 0
            d = self.perlin.random_int() + 1 if d == '#' else 0
            noise = (r + a + n + d) / (4 + landmass)
            return noise


    def generate_map(self,height,width):
        self.perlin = PerlinNoise()
        grid = []
        for y in range(height):
            grid.append([])
            for x in range(width):
                grid[y].append('#' if self.perlin.random_number() > 0.5 else '-')
        return grid

    def generate_altitude(self,height,width):
        self.perlin = PerlinNoise()
        altitude_grid = []
        for y in range(height):
            altitude_grid.append([])
            for x in range(width):
                altitude_grid[y].append(0.1 if self.perlin.random_number() == 0.1 else self.perlin.random_number())
        return altitude_grid

    def nearby_water(self,matrix,y,x):
        for i in range(-1,2):
            for j in range(-1,2):
                if not (i == 0 and j == 0) and not (y + i and x + j) < 0:
                    try:
                        if (i == -1 and j == -1) and matrix[y+i][x+j]== 'water': return 'bottomright_beach'
                        if (i == -1 and j == -1) and matrix[y + i][x + j] == 'water': return 'bottomright_beach'
                        if (i == -1 and j == -1) and matrix[y + i][x + j] == 'water': return 'bottomright_beach'
                        if (i == -1 and j == -1) and matrix[y + i][x + j] == 'water': return 'bottomright_beach'
                        if (i == -1 and j == -1) and matrix[y + i][x + j] == 'water': return 'bottomright_beach'
                        if (i == -1 and j == -1) and matrix[y + i][x + j] == 'water': return 'bottomright_beach'
                        if (i == -1 and j == -1) and matrix[y + i][x + j] == 'water': return 'bottomright_beach'
                        if (i == -1 and j == -1) and matrix[y + i][x + j] == 'water': return 'bottomright_beach'

                    except IndexError:
                        pass
        return False

    def main(self,height,width,landmass):
        self.perlin = PerlinNoise()
        self.biomes = []
        self.grid = self.perlin.generate_map(height,width)
        self.altitude_grid = self.perlin.generate_map(height, width)
        for y in range(height):
            for x in range(width):
                r = '' if y == 0 else self.grid[y - 1][x]
                a = '' if x == width - 1 else self.grid[y][x + 1]
                n = '' if y == height - 1 else self.grid[y + 1][x]
                d = '' if x == 0 else self.grid[y][x - 1]
                self.grid[y][x] = '#' if self.perlin.perlin_noise(landmass,r,a,n,d,'float') > 0.5 else '-'
                self.altitude_grid[y][x] = self.perlin.random_gen('mountain') if self.grid[y][x] == '#' else self.perlin.random_gen('plains')
        self.biome_sorted = [[i + self.perlin.random_gen('mountain') + self.perlin.random_gen('mountain') if 50 < i <= 100 else i + self.perlin.random_gen('plains') + self.perlin.random_gen('mountain') for i in lists] for lists in self.altitude_grid]

        for row_index,row in enumerate(self.biome_sorted):
            for col_index, value in enumerate(row):
                if 0<value<=150: row[col_index] = 'water'
                elif 150<value<=300: row[col_index] = 'plains'

        for row_index, row in enumerate(self.biome_sorted):
            for col_index, value in enumerate(row):
                if value == 'plains':
                    if self.nearby_water(self.biome_sorted, row_index, col_index):
                        row[col_index] = "beach"
        print(self.biome_sorted)

                # elif 150<biomes<=200:
                #     lists[integer] = 'desert'
                # elif 250<biomes<=275:
                #     lists[integer] = 'jungle'
                # elif 275<biomes<=280:
                #     lists[integer] = 'dark_plains'
                # elif 280<biomes<=300:
                #     lists[integer] = 'dark_grass'

        self.biome = [len(x) for x in self.biome_sorted]

        self.objects = []
        for lists in self.biome_sorted:
            self.objects.append(lists[:])
        for lists in self.objects:
            for integer,object in enumerate(lists):
                if object == 'water':
                    lists[integer] = 'rock' if 0 < self.perlin.random_gen('percent') < 5 else ''
                elif object == 'plains':
                    lists[integer] = 'rock' if 0 < self.perlin.random_gen('percent') < 1 else 'tree' if 1 < self.perlin.random_gen('percent') < 5 else ''
                elif object == 'dessert':
                    lists[integer] = 'rock' if 0 < self.perlin.random_gen('percent') < 2 else ''
                elif object == 'jungle':
                    lists[integer] = 'rock' if 0 < self.perlin.random_gen('percent') < 1 else 'tree' if 1 < self.perlin.random_gen('percent') < 5 else ''
                elif object == 'dark_plains':
                    lists[integer] = 'rock' if 0 < self.perlin.random_gen('percent') < 2 else 'tree' if 2 < self.perlin.random_gen('percent') < 5 else ''
                elif object == 'dark_grass':
                    lists[integer] = 'rock' if 0 < self.perlin.random_gen('percent') < 2 else 'tree' if 2 < self.perlin.random_gen('percent') < 5 else ''

        self.object = [len(x) for x in self.objects]
    def random_gen(self,key):
        if key == 'grid':
            return self.grid
        if key == 'object':
            return self.objects
        if key == 'biome_sorted':
            return self.biome_sorted
        elif key == 'mountain':
            mountain = random.randint(50, 100)
            return mountain
        elif key == 'plains':
            not_mountain = random.randint(0, 49)
            return not_mountain
        elif key == 'percent':
            percentage = random.randint(0, 100)
            return percentage
        elif key == 'random':
            objects = 'tree','rock'
            return objects