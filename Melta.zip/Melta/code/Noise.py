from perlin import Perlin
import random
from random import randint as r
from Settings import *
random.seed(1)
class PerlinNoise:
    def __init__(self):
        self.max = 40
        self.min = 20
        self.speed = 10
        self.p = Perlin(r(0,1000))
        self.world = {'water':[],'beach':[],'forest':[],'rainforest':[],'plains':[],'savanna':[],'desert':[],'tree':[],'rock':[]}

    def generate_noise(self):
        high = 0
        low = 0
        self.temp_grid = []
        for y in range(grid_width):
            self.temp_grid.append([])
            for x in range(grid_width):
                ht = self.p.two(x, y)
                if ht > high:
                    high = ht
                if ht < low:
                    low = ht
                noise=self.clamp(self.p.two(x, y), low, high, -10, 50)
                self.temp_grid[y].append(noise)

        self.hum_grid = []
        for y in range(grid_width):
            self.hum_grid.append([])
            for x in range(grid_width):
                ht = self.p.two(x, y)
                if ht > high:
                    high = ht
                if ht < low:
                    low = ht
                noise=self.clamp(self.p.two(x, y), low, high, -10, 50)
                self.hum_grid[y].append(noise)

        self.generate_map()

    def clamp(self,OldValue , OldMin, OldMax, NewMin, NewMax):
        try:
            OldRange = (OldMax - OldMin)
            NewRange = (NewMax - NewMin)
            NewValue = (((OldValue - OldMin) * NewRange) // OldRange) + NewMin
            return NewValue
        except:
            return 0

    def generate_map(self):
        grid = []
        for y in range(grid_width):
            grid.append([])
            for x in range(grid_width):
                grid[y].append(self.biome_output(self.temp_grid[y][x], self.hum_grid[y][x]))

        for row_index,row in enumerate(grid):
            for col_index,value in enumerate(row):
                coord = tile_size*col_index,tile_size*row_index
                biome_value = value.split('_')[0]
                if biome_value == 'water':
                    self.world['water'].append(coord)
                    if r(0, 10) == 1:
                        self.world['rock'].append(coord)
                elif biome_value == 'beach':
                    self.world['beach'].append(coord)
                    if r(0, 10) == 1:
                        self.world['tree'].append(coord)
                elif biome_value == 'forest':
                    self.world['forest'].append(coord)
                    if r(0, 10) == 1:
                        self.world['tree'].append(coord)
                elif biome_value == 'rainforest':
                    self.world['rainforest'].append(coord)
                    if r(0, 10) == 1:
                        self.world['tree'].append(coord)
                elif biome_value == 'plains':
                    self.world['plains'].append(coord)
                    if r(0, 10) == 1:
                        self.world['tree'].append(coord)
                elif biome_value == 'savanna':
                    self.world['savanna'].append(coord)
                    if r(0, 10) == 1:
                        self.world['tree'].append(coord)
                elif biome_value == 'desert':
                    self.world['desert'].append(coord)
                    if r(0, 10) == 1:
                        self.world['tree'].append(coord)

    #water_rock spawns on grass WHEN IT SHOULD ONLY SPAWN ON WATER

    def biome_output(self,temp,rainfall):
        if temp <= 10 and rainfall <= 10:
            return 'water'
        elif 0<temp <=15 and 0<rainfall <= 15:
            return 'rainforest'
        elif 15<temp <=30 and 15<rainfall <= 30:
            return 'forest'
        elif 30<temp<=45 and 30<rainfall <= 45:
            return 'savanna'
        elif 45<temp<=100 and 45<rainfall <= 100:
            return 'desert'
        elif 45<temp<=50 and 0<rainfall <= 100:
            return 'desert'
        else:
            return 'plains'