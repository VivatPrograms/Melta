import pygame

class Object(pygame.sprite.Sprite):
    def __init__(self,pos,groups,key):
        super().__init__(groups)
        self.sprite_type = key
        self.image = pygame.image.load(f'../graphics/objects/{self.sprite_type}.png')
        self.rect = self.image.get_rect(topleft=pos)
        self.hitbox = self.rect.inflate(0,-10)