from Settings import *
from Object import Object
from Player import Player
from Map import Map
from Import_support import *
from UI import UI

class ObjectCreation:
    def __init__(self):
        self.display_surface = pygame.display.get_surface()
        self.visible_sprites = YSortCameraGroup()
        self.obstacle_sprites = pygame.sprite.Group()
        self.player = Player((grid_width // 2 * tile_size, grid_width // 2 * tile_size), [self.visible_sprites], self.obstacle_sprites)
        self.world = Map()
        self.generate_map()
    def generate_map(self):
        for key in self.world.grid.keys():
            for value in self.world.grid[key]:
                coord = value
                if key == 'rock':
                    self.object = Object(coord,[self.visible_sprites,self.obstacle_sprites],'rock')
                elif key == 'tree':
                    self.object = Object(coord,[self.visible_sprites,self.obstacle_sprites],'tree')

    def run(self):
        self.visible_sprites.custom_draw(self.player,self.world)
        self.visible_sprites.update()

class YSortCameraGroup(pygame.sprite.Group):
    def __init__(self):
        #General setup
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.half_width = self.display_surface.get_size()[0] // 2
        self.half_height = self.display_surface.get_size()[1] // 2
        self.offset = pygame.math.Vector2()
        #Setup for rectangles
        self.window_rect = pygame.Rect((0, 0), window)
        self.ui = UI()

    def custom_draw(self,player,world):
        #Getting the offset
        self.offset.x = player.rect.centerx - self.half_width
        self.offset.y = player.rect.centery - self.half_height
        #Drawing map'
        map_rect = world.world_surf.get_rect()
        map_offset_pos = map_rect.topleft - self.offset
        self.display_surface.blit(world.world_surf,map_offset_pos)
        #Drawing UI
        if player.inventory_open:
            self.display_surface.blit(self.ui.surf,(400,800))
        #Drawing sprites
        for sprite in sorted(self.sprites(),key=lambda sprite: sprite.rect.centery):
            #sprite is an instance of a class
            type = sprite.type
            offset_pos = sprite.rect.topleft - self.offset
            #drawing the inventory
            self.ui.collision_check(type,offset_pos,sprite)

            inside_window = self.window_rect.colliderect(1,1,1,1)
            if inside_window:
                self.display_surface.blit(sprite.image,offset_pos)
