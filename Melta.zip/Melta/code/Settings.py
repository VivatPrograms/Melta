tile_size = 64
FPS = 60
WIDTH,HEIGHT = 1000,800
window = (WIDTH,HEIGHT)

#Settings for map
grid_width = 30
watermass = 1.5

#biomes for map
plains = 'P'
stone = 'S'
dessert = 'D'
trees = 'T'


