import pygame
from Noise import PerlinNoise
from Settings import *
from Import_support import import_sprite_sheet

class Map:
    def __init__(self):
        self.Tile_map = import_sprite_sheet('../graphics/tilemap/Floor.png')
        self.perlin = PerlinNoise()
        self.perlin.generate_noise()
        self.grid = self.perlin.world
        self.world_surf = pygame.Surface((tile_size * grid_width, tile_size * grid_width))
        self.run()

    def run(self):
        for key in self.grid.keys():
            for value in self.grid[key]:
                rect = self.Tile_map[0].get_rect(topleft=(value))
                if key == 'water':
                    self.world_surf.blit(self.Tile_map[22*12+8], rect)
                elif key == 'beach':
                    self.world_surf.blit(self.Tile_map[22*1+1], rect)
                elif key == 'forest':
                    self.world_surf.blit(self.Tile_map[22*11+3], rect)
                elif key == 'rainforest':
                    self.world_surf.blit(self.Tile_map[22*12+2], rect)
                elif key == 'savanna':
                    self.world_surf.blit(self.Tile_map[22*5+3], rect)
                elif key == 'desert':
                    self.world_surf.blit(self.Tile_map[22*5], rect)
                elif key == 'plains':
                    self.world_surf.blit(self.Tile_map[22*12+3], rect)