width,height = 5,5
lst = []
for y in range(height):
    lst.append([])
    for x in range(width):
        lst[y].append('.')
print(lst)
