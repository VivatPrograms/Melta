import pygame
from Settings import *

class Drop(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((tile_size,tile_size))
        self.image.fill('red')
        self.rect = self.image.get_rect(center=(0,0))