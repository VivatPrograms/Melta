import pygame
from Settings import *
from Import_support import import_folder

class Player(pygame.sprite.Sprite):
    def __init__(self,pos,groups,obstacle_sprites):
        super().__init__(groups)
        self.image = pygame.image.load('../graphics/test/player.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = pos)
        self.hitbox = self.rect.inflate(0,-26)
        #general
        self.frame_index = 0
        self.animation_speed = 0.15
        #movement
        self.direction = pygame.math.Vector2()
        self.speed = 600 // FPS
        self.moving = 'down'

        self.obstacle_sprites = obstacle_sprites

        self.import_player_assets()

        self.x_off = 0
        self.y_off = 0

        self.type = 'player'

        #inventory
        self.inventory_open = True
        self.key_pressed = True

    def import_player_assets(self):
        player_path = '../graphics/player'
        self.animations = {'up':[],'down':[],'left':[],'right':[],
                           'up_idle':[],'down_idle':[],'left_idle':[],'right_idle':[],
                           'up_attack':[],'down_attack':[],'left_attack':[],'right_attack':[]}
        for animation in self.animations.keys():
            full_path = import_folder(player_path + '/' + animation)
            self.animations[animation] = full_path

    def input(self):
        keys = pygame.key.get_pressed()

        #movement
        if keys[pygame.K_w]:
            self.direction.y = -1
            self.moving = 'up'
            self.y_off -= 1
        elif keys[pygame.K_s]:
            self.direction.y = 1
            self.moving = 'down'
            self.y_off += 1
        else:
            self.direction.y = 0
        if keys[pygame.K_a]:
            self.direction.x = -1
            self.moving = 'left'
            self.x_off -= 1
        elif keys[pygame.K_d]:
            self.direction.x = 1
            self.moving = 'right'
            self.x_off += 1
        else:
            self.direction.x = 0

        #inventory
        if keys[pygame.K_e]:
            if not self.key_pressed:
                self.key_pressed = True
                self.inventory_open = not self.inventory_open
        else:
            self.key_pressed = False

    def move(self,speed):
        if self.direction.magnitude() !=0:
            self.direction = self.direction.normalize()

        self.hitbox.x += self.direction.x * speed
        self.collision('horizontal')
        self.hitbox.y += self.direction.y * speed
        self.collision('vertical')
        self.rect.center = self.hitbox.center

    def collision(self,direction):
        if direction == 'horizontal':
            for sprite in self.obstacle_sprites:
                if sprite.hitbox.colliderect(self.hitbox):
                    if self.direction.x > 0:
                        self.hitbox.right = sprite.hitbox.left
                    if self.direction.x < 0:
                        self.hitbox.left = sprite.hitbox.right
        if direction == 'vertical':
            for sprite in self.obstacle_sprites:
                if sprite.hitbox.colliderect(self.hitbox):
                    if self.direction.y > 0:
                        self.hitbox.bottom = sprite.hitbox.top
                    if self.direction.y < 0:
                        self.hitbox.top = sprite.hitbox.bottom

    def status(self):
        if self.direction.x == 0 and self.direction.y == 0:
            if not 'idle' in self.moving and not 'attack' in self.moving:
                self.moving = self.moving + '_idle'

    def animate(self,animations):
        animation = self.animations[animations]

        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0
        self.image = animation[int(self.frame_index)]
        self.rect = self.image.get_rect(center=self.hitbox.center)

    def update(self):
        self.input()
        self.status()
        self.animate(self.moving)
        self.move(self.speed)