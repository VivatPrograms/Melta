import pygame
from Settings import *
from Item import Item

class UI:
    def __init__(self):
        self.sprite_image = pygame.Surface((128, 128))
        self.screen = pygame.display.get_surface()
        self.inventory_dict = {0: {0:{'ID':None,'amount':0},1:{'ID':None,'amount':0},2:{'ID':None,'amount':0}},
                               1: {0:{'ID':None,'amount':0},1:{'ID':None,'amount':0},2:{'ID':None,'amount':0}},
                               2: {0:{'ID':None,'amount':0},1:{'ID':None,'amount':0},2:{'ID':None,'amount':0}}}
        self.drop = False
        self.first_collect = True
        self.inventory_logic(None,self.first_collect)

    def collision_check(self,type,offset_pos,sprite):
        mouse_pos = pygame.mouse.get_pos()
        rect = self.sprite_image.get_rect(topleft=offset_pos)
        if rect.collidepoint(mouse_pos) and pygame.mouse.get_pressed()[0]:
            if type == 'rock':
                self.item = Item(2, 0, 1, offset_pos + (tile_size // 2, tile_size // 2))
            elif type == 'tree':
                self.item = Item(1, 0, 1, offset_pos + (tile_size // 2, tile_size // 2))
            self.drop = True
            sprite.kill()
        if self.drop:
            self.screen.blit(self.item.image, self.item.rect)
            if self.item.rect.collidepoint(mouse_pos) and pygame.mouse.get_pressed()[0]:
                self.inventory_logic(self.item.ID,self.first_collect)
                self.drop = False
                self.first_collect = False

    def inventory_logic(self,ID,first):
        empty_slot_check = True
        inv_font = pygame.font.Font(None, 32)
        self.surf = pygame.Surface((3*tile_size,3*tile_size))

        for y in self.inventory_dict.keys():
            for x in self.inventory_dict.keys():
                pygame.draw.rect(self.surf, 'gold', pygame.Rect((x * tile_size, y * tile_size), (tile_size, tile_size)),1)
                if empty_slot_check:
                    if self.inventory_dict[y][x]['ID'] == None:
                        available_y = y
                        available_x = x
                        empty_slot_check = False
                        if first:
                            self.inventory_dict[available_y][available_x]['ID'] = ID
                            self.inventory_dict[available_y][available_x]['amount'] = 0
                        if self.inventory_dict[available_y][available_x]['ID'] != None:
                            if self.inventory_dict[available_y][available_x]['ID'] == ID:
                                self.inventory_dict[available_y][available_x]['ID'] = self.inventory_dict[available_y][available_x]['ID']
                                self.inventory_dict[available_y][available_x]['amount'] += 1
                        elif self.inventory_dict[y][x]['ID'] == None:
                            self.inventory_dict[y][x]['ID'] = ID
                            self.inventory_dict[y][x]['amount'] += 1

                if self.inventory_dict[y][x]['ID'] == 2:
                    pygame.draw.rect(self.surf, 'red',pygame.Rect((x * tile_size + tile_size // 4, y * tile_size + tile_size // 4),(tile_size // 2, tile_size // 2)))
                    inv_text = inv_font.render(str(self.inventory_dict[y][x]['amount']), True, 'white')
                    inv_font_rect = inv_text.get_rect(topleft=(tile_size*x+50,tile_size*y+44))
                    self.surf.blit(inv_text, inv_font_rect)