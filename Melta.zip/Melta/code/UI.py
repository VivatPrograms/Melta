import pygame
from Settings import *
from Item import Item

class UI:
    def __init__(self):

        self.screen = pygame.display.get_surface()
        self.inventory = {0: {'ID':None,'amount':0},1:{'ID':None,'amount':0},2:{'ID':None,'amount':0},
                        3:{'ID':None,'amount':0},4:{'ID':None,'amount':0},5:{'ID':None,'amount':0},
                        6:{'ID':None,'amount':0},7:{'ID':None,'amount':0},8:{'ID':None,'amount':0}}
        self.surf = pygame.Surface((9*tile_size,1*tile_size))
        self.inv_font = pygame.font.Font(None, 32)

    def centered(self,connector_type,tuple_one,tuple_two):
        if connector_type == 'add':
            return (tuple_one[0] + tuple_two[0],tuple_one[1] + tuple_two[1])
        if connector_type == 'subtract':
            return (tuple_one[0] - tuple_two[0],tuple_one[1] - tuple_two[1])
        if connector_type == 'multiply':
            return (tuple_one[0] * tuple_two[0],tuple_one[1] * tuple_two[1])
        if connector_type == 'divide':
            return (tuple_one[0] // tuple_two[0],tuple_one[1] // tuple_two[1])

    def object_breaking_collecting(self,type,object,sprite,groups):
        mouse_pos = pygame.mouse.get_pos()
        if object.collidepoint(mouse_pos) and pygame.mouse.get_pressed()[0]:
            if type == 'tree':
                self.item = Item(1,0,1,sprite.rect.center,[groups])
            elif type == 'rock':
                self.item = Item(2,0,1,sprite.rect.center,[groups])
            elif type == 'item_drop':
                self.add_item(sprite.ID,1)
            sprite.kill()

    def add_item(self, ID, amount):
        for slot in self.inventory.values():
            if slot['ID'] == ID:
                slot['amount'] += amount
                return True

        for slot in self.inventory.values():
            if slot['ID'] == None:
                slot['ID'] = ID
                slot['amount'] += amount
                return True

        return False

    def remove_item(self, ID, amount):
        old_inventory = {}
        for key, value in self.inventory.items():
            old_inventory[key] = {**value}

        for slot in self.inventory.values():
            if slot['ID'] == ID:
                if slot['amount'] >= amount:
                    slot['amount'] -= amount
                    if slot['amount'] == 0:
                        slot['ID'] = None
                    return True
                else:
                    amount -= slot['amount']
                    slot['ID'] = None
                    slot['amount'] = 0

        self.inventory = old_inventory
        return False

    def draw(self):
        self.surf.fill('black')
        for x in range(9):
            pygame.draw.rect(self.surf, 'gold', pygame.Rect((x * tile_size, 0 * tile_size), (tile_size, tile_size)), 1)
            if self.inventory[x]['ID'] == 2:
                pygame.draw.rect(self.surf, 'yellow',pygame.Rect((x * tile_size + tile_size // 4, 0 * tile_size + tile_size // 4),(tile_size // 2, tile_size // 2)))
            if self.inventory[x]['ID'] == 1:
                pygame.draw.rect(self.surf, 'green',pygame.Rect((x * tile_size + tile_size // 4, 0 * tile_size + tile_size // 4),(tile_size // 2, tile_size // 2)))
            inv_text = self.inv_font.render(str(self.inventory[x]['amount']), True, 'white').convert_alpha()
            inv_font_rect = inv_text.get_rect(topleft=(tile_size * x, tile_size * 0))
            self.surf.blit(inv_text, inv_font_rect)

    def update(self,type,offset_pos,sprite,groups):
        self.object_breaking_collecting(type,offset_pos,sprite,groups)
        self.draw()