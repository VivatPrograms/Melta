import pygame
from Settings import *
from Item import Item
from Object import Object

class UI:
    def __init__(self):
        self.screen = pygame.display.get_surface()
        self.inventory = {0: {'ID':None,'amount':0},1:{'ID':None,'amount':0},2:{'ID':None,'amount':0},
                        3:{'ID':None,'amount':0},4:{'ID':None,'amount':0},5:{'ID':None,'amount':0},
                        6:{'ID':None,'amount':0},7:{'ID':None,'amount':0},8:{'ID':None,'amount':0}}
        self.inventory_surf = pygame.Surface((9*tile_size,1*tile_size))
        self.inv_font = pygame.font.Font(None, 32)
        self.click_cooldown = 400
        self.clicking_cooldown = False
        self.click_time = None
        self.clicking = False

    def collect_break_place_item(self,type,object,offset,sprite,groups):
        mouse_pos = pygame.mouse.get_pos()
        offset_pos = pygame.math.Vector2()
        offset_pos.x = ((mouse_pos[0] + offset[0])//tile_size)*tile_size
        offset_pos.y = ((mouse_pos[1] + offset[1])//tile_size)*tile_size

        if pygame.mouse.get_pressed()[0]:
            self.clicking = True
            self.click_time = pygame.time.get_ticks()

            if object.collidepoint(mouse_pos):
                if type != 'block':
                    if type == 'tree':
                       Item(1,0,1,sprite.rect.center,[groups[0]],'green')
                    elif type == 'rock':
                        Item(2,0,1,sprite.rect.center,[groups[0]],'yellow')
                    elif type == 'item_drop':
                        self.add_item(sprite.ID,1)
                    sprite.kill()
                return None
            if self.clicking_cooldown == False:
                Object(offset_pos, [groups], 'block')

    def cooldown(self):
        current_time = pygame.time.get_ticks()
        if self.clicking:
            if current_time - self.click_time >= self.click_cooldown:
                self.clicking_cooldown = False
                self.clicking = not self.clicking
            else:
                self.clicking_cooldown = True

    def add_item(self, ID, amount):
        for slot in self.inventory.values():
            if slot['ID'] == ID:
                slot['amount'] += amount
                return True

        for slot in self.inventory.values():
            if slot['ID'] == None:
                slot['ID'] = ID
                slot['amount'] += amount
                return True

        return False

    def remove_item(self, ID, amount):
        old_inventory = {}
        for key, value in self.inventory.items():
            old_inventory[key] = {**value}

        for slot in self.inventory.values():
            if slot['ID'] == ID:
                if slot['amount'] >= amount:
                    slot['amount'] -= amount
                    if slot['amount'] == 0:
                        slot['ID'] = None
                    return True
                else:
                    amount -= slot['amount']
                    slot['ID'] = None
                    slot['amount'] = 0

        self.inventory = old_inventory
        return False

    def draw(self):
        self.inventory_surf.fill('black')
        for x in range(9):
            pygame.draw.rect(self.inventory_surf, 'gold', pygame.Rect((x * tile_size, 0 * tile_size), (tile_size, tile_size)), 1)
            if self.inventory[x]['ID'] == 2:
                pygame.draw.rect(self.inventory_surf, 'yellow',pygame.Rect((x * tile_size + tile_size // 4, 0 * tile_size + tile_size // 4),(tile_size // 2, tile_size // 2)))
            if self.inventory[x]['ID'] == 1:
                pygame.draw.rect(self.inventory_surf, 'green',pygame.Rect((x * tile_size + tile_size // 4, 0 * tile_size + tile_size // 4),(tile_size // 2, tile_size // 2)))
            inv_text = self.inv_font.render(str(self.inventory[x]['amount']), True, 'white').convert_alpha()
            inv_font_rect = inv_text.get_rect(topleft=(tile_size * x, tile_size * 0))
            self.inventory_surf.blit(inv_text, inv_font_rect)

    def update(self,type,offset_pos,offset,sprite,groups):
        self.collect_break_place_item(type,offset_pos,offset,sprite,groups)
        self.cooldown()
        self.draw()
